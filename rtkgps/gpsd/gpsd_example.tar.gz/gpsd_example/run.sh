#g++ main.cpp GpsPosition.cpp-I/home/dy/workstation/stone/rtkgps/gpsd/gpsd -L/home/dy/workstation/stone/rtkgps/gpsd/gpsd -lm -lpthread -lgps
g++ main.cpp GpsPosition.cpp -I/home/dy/workstation/stone/rtkgps/gpsd/gpsd -lm -lpthread -lgps -lpthread -std=c++11
