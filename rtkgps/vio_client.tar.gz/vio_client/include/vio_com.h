#ifndef PI_VIO_COM_H
#define PI_VIO_COM_H

typedef struct PILocalizationVioMsg_
{
  // position of the optical center of the camera 
  // with respect to the world origin
  double tx;
  double ty;
  double tz;

  // orientation of the optical center of the camera
  // in form of a unit quaternion with respect to the world origin
  double qx;
  double qy;
  double qz;
  double qw;
} PILocalizationVioMsg;

#endif
