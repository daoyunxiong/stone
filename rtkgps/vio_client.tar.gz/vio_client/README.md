VIO client
===========

## nanomsg

For more details about nanomsg protocols, please refer to [nanomsg](http://nanomsg.org/v1.1.2/nanomsg.html).

## dependencies:

nanomsg: >v1.1.2
boost: >1.65.0