
/*  test demo
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <netinet/in.h>  /* For htonl and ntohl */
#include <unistd.h>
#include <thread>
#include <chrono>
#include <iostream>
#include <vector>
#include <functional>
#include <iomanip>
#include <iterator>

#include <Eigen/Dense>

#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/core/eigen.hpp>
#include <opencv2/core/affine.hpp>

#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>

#include <msg_utils/pi_msg_com.h>
#include <msg_utils/pi_msg_adaptor.h>
#include "rtk_gps.h"
#include "vio_com.h"

using namespace std;
using namespace Eigen;
using namespace cv;

using namespace PIAUTO::msg;
RTK_GPS *rtk_gps_p;
char data_buf[500];
FILE *fp_vio, *fp_gps;

uint64_t getCurrentTicks() 
{
            timeval t;
            gettimeofday(&t,NULL);
            return static_cast<uint64_t>( t.tv_sec ) * 1000000ull + static_cast<uint64_t>( t.tv_usec );
}

int processVIOPos(int handler, p_pi_msg_envelope_t p_env, const char* body, unsigned int len)
{
    rtk_data_t rtk_data;
    uint64_t time_ms = getCurrentTicks();

//get vio data
    std::cout << "one vio pos recieved" << std::endl;
    if(p_env->type == PIMSG_LOCALIZATION_VIO_PUBLISH_POS)
    {
        PILocalizationVioMsg msg;
        memcpy(&msg, body, sizeof(PILocalizationVioMsg));

        std::cout << "one pos: " << std::setprecision(7) << msg.tx << " "<< msg.ty << " " << msg.tz << " "
                    << msg.qx << " "<< msg.qy << " " << msg.qz << " " << msg.qw << std::endl;
        fprintf(fp_vio, "%ju,%f,%f,%f\n", time_ms, msg.tx, msg.ty, msg.tz); 
        fflush(fp_vio);

//get gps data
        rtk_data = rtk_gps_p->get_gps_data();
        printf("gps lat: %4.10lf  lon: %4.10lf \n", rtk_data.pos_llh.lat, rtk_data.pos_llh.lon);
        fprintf(fp_gps, "%ju,%d,%4.10f,%4.10f,%f,%f,%d\n", time_ms, rtk_data.pos_llh.tow, rtk_data.pos_llh.lat, rtk_data.pos_llh.lon, rtk_data.heading_kalman, rtk_data.heading_data, rtk_data.pos_llh.flags); 
        fflush(fp_gps);
    }

    return 1;
}


int main (int argc, char **argv)
{
    int rc;

    time_t timer;
    struct tm *tblock;
    time(&timer);
    tblock = localtime(&timer);
   

    if(argc != 2)
    {
        std::cout << "Usage: " << argv[0] << " [vio target you subscribe to]"
                << "Example: " << argv[0] << " tcp://192.168.1.108"
                << std::endl;

        return -1;
    }
    char filename_vio[100];
    char filename_gps[100];
    memset(filename_vio, 0, sizeof(filename_vio));
    memset(filename_gps, 0, sizeof(filename_vio));
    
    sprintf(filename_gps, "gps_zte_%02d%02d_%02d%02d%02d.txt", tblock->tm_mon + 1, tblock->tm_mday, tblock->tm_hour, tblock->tm_min, tblock->tm_sec);
    sprintf(filename_vio, "msckf_vio_%02d%02d_%02d%02d%02d.txt", tblock->tm_mon + 1, tblock->tm_mday, tblock->tm_hour, tblock->tm_min, tblock->tm_sec);
    
    fp_vio = fopen(filename_vio, "w+");
    fp_gps = fopen(filename_gps, "w+");

    auto msg_adp = std::make_shared<PIMsgAdaptor>();

    char url_t[64];

    sprintf(url_t, "%s:%s", argv[1], "4444");
    int sub_handler = msg_adp->registerOneMessageChannel({NN_SUB, url_t, "vio", -1});

    msg_adp->addSubscriberToSubMsg([&](int handler, p_pi_msg_envelope_t p_env, const char* body, unsigned int len){
        return processVIOPos(handler, p_env, body, len);
    });

    msg_adp->startRecvLoop();

    char port_name[] = "/dev/ttyUSB0";
    char *port_p = port_name;

    RTK_GPS rtk_gps(port_p);
    rtk_gps_p = &rtk_gps;

    int i = 0;
    while(1)
    {
        // TODO
    }

    fclose(fp_vio);
    fclose(fp_gps);
    return 0;
}
